
public class BST<K extends Comparable<K>, T> implements Map<K, T> {

	@Override
	public boolean empty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean full() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T retrieve() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(T e) {
		// TODO Auto-generated method stub

	}

	@Override
	public Pair<Boolean, Integer> find(K key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pair<Boolean, Integer> insert(K key, T data) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pair<Boolean, Integer> remove(K key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<K> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
