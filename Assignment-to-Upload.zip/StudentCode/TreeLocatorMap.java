
public class TreeLocatorMap<K extends Comparable<K>> implements LocatorMap<K> {

	@Override
	public Map<K, Location> getMap() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Locator<K> getLocator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pair<Boolean, Integer> add(K k, Location loc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pair<Boolean, Integer> move(K k, Location loc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pair<Location, Integer> getLoc(K k) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pair<Boolean, Integer> remove(K k) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<K> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pair<List<K>, Integer> getInRange(Location lowerLeft, Location upperRight) {
		// TODO Auto-generated method stub
		return null;
	}

}
