
public class TreeLocator<T> implements Locator<T> {

	@Override
	public int add(T e, Location loc) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Pair<List<T>, Integer> get(Location loc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pair<Boolean, Integer> remove(T e, Location loc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pair<Location, List<T>>> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pair<List<Pair<Location, List<T>>>, Integer> inRange(Location lowerLeft, Location upperRight) {
		// TODO Auto-generated method stub
		return null;
	}

}
