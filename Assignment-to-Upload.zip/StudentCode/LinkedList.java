
public class LinkedList<T> implements List<T> {

	@Override
	public boolean empty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean full() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void findFirst() {
		// TODO Auto-generated method stub

	}

	@Override
	public void findNext() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean last() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T retrieve() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(T e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insert(T e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove() {
		// TODO Auto-generated method stub

	}

}
